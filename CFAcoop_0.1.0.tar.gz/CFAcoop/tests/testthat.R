library(testthat)
library(CFAcoop)

test_check("CFAcoop")
